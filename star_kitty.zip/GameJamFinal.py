
import random
import sys
import pygame
from pygame.locals import *
from termcolor import colored
from pygame import mixer 

window_width = 700
window_height = 520


window = pygame.display.set_mode((window_width, window_height))
elevation = window_height * 0.8
game_images = {}
framepersecond = 32
pipe1image = 'pipe1.png'
background1_image = 'background1.jpg'
catplayer_image = 'cat.png'
sealevel_image = 'background2.jfif'
size = [700, 520]
screen = pygame.display.set_mode(size)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
 
pygame.init()
 

size = [700, 500]
screen = pygame.display.set_mode(size)
 
pygame.display.set_caption("Instructions")
 
done = False
clock = pygame.time.Clock()
 

 

font = pygame.font.Font(None, 36)
 
display_instructions = True
instruction_page = 1
 

while not done and display_instructions:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
            instruction_page += 1
            if instruction_page == 3:
                display_instructions = False

    screen.fill(BLACK)
 
    if instruction_page == 1:
       
 
        text = font.render("Welcom to kitty fire, press space to continue", True, WHITE)
        screen.blit(text, [20, 40])
 
        text = font.render("Page 1/2", True, WHITE)
        screen.blit(text, [40, 10])
 
    if instruction_page == 2:
       
        text = font.render("Use space bar to survive your intergalactic adventure", True, WHITE)
        screen.blit(text, [20, 40])
 
        text = font.render("Page 2/2", True, WHITE)
        screen.blit(text, [40, 10])
 
    
    clock.tick(60)
 
    
    pygame.display.flip()



def flappygame():
	your_score = 0
	horizontal = int(window_width/5)
	vertical = int(window_width/2)
	ground = 0
	mytempheight = 100


	first_pipe1 = createpipe1()
	second_pipe1 = createpipe1()


	down_pipe1s = [
		{'x': window_width+300-mytempheight,
		'y': first_pipe1[1]['y']},
		{'x': window_width+300-mytempheight+(window_width/2),
		'y': second_pipe1[1]['y']},
	]


	up_pipe1s = [
		{'x': window_width+300-mytempheight,
		'y': first_pipe1[0]['y']},
		{'x': window_width+200-mytempheight+(window_width/2),
		'y': second_pipe1[0]['y']},
	]


	pipe1VelX = -4

	
	cat_velocity_y = -9
	cat_Max_Vel_Y = 10
	cat_Min_Vel_Y = -8
	catAccY = 1

	cat_flap_velocity = -8
	cat_flapped = False
	while True:
		for event in pygame.event.get():
			if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
				pygame.quit()
				sys.exit()
			if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
				if vertical > 0:
					cat_velocity_y = cat_flap_velocity
					cat_flapped = True

		
		game_over = isGameOver(horizontal,
							vertical,
							up_pipe1s,
							down_pipe1s)
		if game_over:
			return

		
		playerMidPos = horizontal + game_images['flappycat'].get_width()/2
		for pipe1 in up_pipe1s:
			pipe1MidPos = pipe1['x'] + game_images['pipe1image'][0].get_width()/2
			if pipe1MidPos <= playerMidPos < pipe1MidPos + 4:
				your_score += 1
				print(f"Your your_score is {your_score}")

		if cat_velocity_y < cat_Max_Vel_Y and not cat_flapped:
			cat_velocity_y += catAccY

		if cat_flapped:
			cat_flapped = False
		playerHeight = game_images['flappycat'].get_height()
		vertical = vertical + \
			min(cat_velocity_y, elevation - vertical - playerHeight)

		
		for upperpipe1, lowerpipe1 in zip(up_pipe1s, down_pipe1s):
			upperpipe1['x'] += pipe1VelX
			lowerpipe1['x'] += pipe1VelX

		
		if 0 < up_pipe1s[0]['x'] < 5:
			newpipe1 = createpipe1()
			up_pipe1s.append(newpipe1[0])
			down_pipe1s.append(newpipe1[1])

		
		if up_pipe1s[0]['x'] < -game_images['pipe1image'][0].get_width():
			up_pipe1s.pop(0)
			down_pipe1s.pop(0)

		
		window.blit(game_images['background1'], (0, 0))
		for upperpipe1, lowerpipe1 in zip(up_pipe1s, down_pipe1s):
			window.blit(game_images['pipe1image'][0],
						(upperpipe1['x'], upperpipe1['y']))
			window.blit(game_images['pipe1image'][1],
						(lowerpipe1['x'], lowerpipe1['y']))

		window.blit(game_images['sea_level'], (ground, elevation))
		window.blit(game_images['flappycat'], (horizontal, vertical))

		
		numbers = [int(x) for x in list(str(your_score))]
		width = 0

		
		for num in numbers:
			width += game_images['scoreimages'][num].get_width()
		Xoffset = (window_width - width)/1.1

		
		for num in numbers:
			window.blit(game_images['scoreimages'][num],
						(Xoffset, window_width*0.02))
			Xoffset += game_images['scoreimages'][num].get_width()

		
		pygame.display.update()
		framepersecond_clock.tick(framepersecond)


def isGameOver(horizontal, vertical, up_pipe1s, down_pipe1s):
	if vertical > elevation - 25 or vertical < 0:
		return True

	for pipe1 in up_pipe1s:
		pipe1Height = game_images['pipe1image'][0].get_height()
		if(vertical < pipe1Height + pipe1['y'] and\
		abs(horizontal - pipe1['x']) < game_images['pipe1image'][0].get_width()):
			return True

	for pipe1 in down_pipe1s:
		if (vertical + game_images['flappycat'].get_height() > pipe1['y']) and\
		abs(horizontal - pipe1['x']) < game_images['pipe1image'][0].get_width():
			return True
	return False


def createpipe1():
	offset = window_height/3
	pipe1Height = game_images['pipe1image'][0].get_height()
	y2 = offset + \
		random.randrange(
			0, int(window_height - game_images['sea_level'].get_height() - 1.2 * offset))
	pipe1X = window_width + 10
	y1 = pipe1Height - y2 + offset
	pipe1 = [
		
		{'x': pipe1X, 'y': -y1},

		
		{'x': pipe1X, 'y': y2}
	]
	return pipe1



if __name__ == "__main__":

		
	pygame.init()
	framepersecond_clock = pygame.time.Clock()

	
	pygame.display.set_caption('kitty Fire')

	
	game_images['scoreimages'] = (
		pygame.image.load('0.png').convert_alpha(),
		pygame.image.load('1.png').convert_alpha(),
		pygame.image.load('2.png').convert_alpha(),
		pygame.image.load('3.png').convert_alpha(),
		pygame.image.load('4.png').convert_alpha(),
		pygame.image.load('5.png').convert_alpha(),
		pygame.image.load('6.png').convert_alpha(),
		pygame.image.load('7.png').convert_alpha(),
		pygame.image.load('8.png').convert_alpha(),
		pygame.image.load('9.png').convert_alpha()
	)
	game_images['flappycat'] = pygame.image.load(
		catplayer_image).convert_alpha()
	game_images['sea_level'] = pygame.image.load(
		sealevel_image).convert_alpha()
	game_images['background1'] = pygame.image.load(
		background1_image).convert_alpha()
	game_images['pipe1image'] = (pygame.transform.rotate(pygame.image.load(
		pipe1image).convert_alpha(), 180), pygame.image.load(
	pipe1image).convert_alpha())







	

	while True:

		
		mixer.init()
		mixer.music.load('My-Song-27.ogg')
		mixer.music.play()


		horizontal = int(window_width/5)
		vertical = int(
			(window_height - game_images['flappycat'].get_height())/2)
		ground = 0
		while True:
			for event in pygame.event.get():

				
				if event.type == QUIT or (event.type == KEYDOWN and \
										event.key == K_ESCAPE):
					pygame.quit()
					sys.exit()

				
				elif event.type == KEYDOWN and (event.key == K_SPACE or\
												event.key == K_UP):
					flappygame()

				
				else:
					window.blit(game_images['background1'], (0, 0))
					window.blit(game_images['flappycat'],
								(horizontal, vertical))
					window.blit(game_images['sea_level'], (ground, elevation))
					pygame.display.update()
					framepersecond_clock.tick(framepersecond)
